/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_terms`; */
/* PRE_TABLE_NAME: `1696412387_wp_terms`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1696412387_wp_terms` ( `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '', `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '', `term_group` bigint(10) NOT NULL DEFAULT 0, PRIMARY KEY (`term_id`), KEY `slug` (`slug`(191)), KEY `name` (`name`(191))) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1696412387_wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES (1,'Uncategorized','uncategorized',0),(2,'Nav-fr','nav-fr',0),(3,'English','en',0),(4,'English','pll_en',0),(5,'pll_645b4b0a721c4','pll_645b4b0a721c4',0),(6,'Français','fr',1),(7,'Français','pll_fr',0),(8,'Uncategorized','uncategorized-fr',0),(10,'pll_645b4b5ee16bd','pll_645b4b5ee16bd',0),(11,'Nav-en','nav-en',0),(12,'pll_645e044490cec','pll_645e044490cec',0),(13,'pll_645e0598db5a0','pll_645e0598db5a0',0),(14,'pll_645e05c773bcf','pll_645e05c773bcf',0),(15,'pll_645e05ec6f67d','pll_645e05ec6f67d',0),(16,'pll_645e061198af8','pll_645e061198af8',0),(17,'pll_645e066e439e3','pll_645e066e439e3',0),(18,'pll_645e068b5a404','pll_645e068b5a404',0);
