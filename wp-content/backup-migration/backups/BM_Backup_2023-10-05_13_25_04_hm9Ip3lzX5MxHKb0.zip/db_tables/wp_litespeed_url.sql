/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_litespeed_url`; */
/* PRE_TABLE_NAME: `1696512304_wp_litespeed_url`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1696512304_wp_litespeed_url` ( `id` bigint(20) NOT NULL AUTO_INCREMENT, `url` varchar(500) NOT NULL, `cache_tags` varchar(1000) NOT NULL DEFAULT '', PRIMARY KEY (`id`), UNIQUE KEY `url` (`url`(191)), KEY `cache_tags` (`cache_tags`(191))) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
