/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_yoast_indexable_hierarchy`; */
/* PRE_TABLE_NAME: `1696512304_wp_yoast_indexable_hierarchy`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1696512304_wp_yoast_indexable_hierarchy` ( `indexable_id` int(11) unsigned NOT NULL, `ancestor_id` int(11) unsigned NOT NULL, `depth` int(11) unsigned DEFAULT NULL, `blog_id` bigint(20) NOT NULL DEFAULT 1, PRIMARY KEY (`indexable_id`,`ancestor_id`), KEY `indexable_id` (`indexable_id`), KEY `ancestor_id` (`ancestor_id`), KEY `depth` (`depth`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1696512304_wp_yoast_indexable_hierarchy` (`indexable_id`, `ancestor_id`, `depth`, `blog_id`) VALUES (1,0,0,1),(2,0,0,1),(3,0,0,1),(5,0,0,1),(6,0,0,1),(7,5,1,1),(8,5,1,1),(9,5,1,1),(10,5,1,1),(11,5,1,1),(12,0,0,1),(13,0,0,1),(14,12,1,1),(15,12,1,1),(16,12,1,1),(17,12,1,1),(18,12,1,1),(19,0,0,1),(22,0,0,1),(26,0,0,1);
